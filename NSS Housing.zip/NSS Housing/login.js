
function direction(){
            var mail=document.form1.email.value;
                var pw=document.form1.pscode.value;
                var username = "rashid";
                var password = "ras";
                if ((mail == username) && (pw == password)){
                    alert("Login Sucessful");
                    new_page();
                }
                
                else {
                    alert ("Login was unsucessful, please check your username and password");
                    
                }
                    }