#This is the backend of NSS Housing
def log_in():
    name1 ='rashid0272824406@gmail.com'
    
    if email = name1
    print('Hello')
    print('World')

log_in()