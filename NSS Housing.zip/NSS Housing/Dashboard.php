<!DOCTYPE html>
<html>
    <head>
        <title>Dasboard</title>
    </head>
<body>

<?php
echo "My first PHP script!";
?> 

</body>
</html>
